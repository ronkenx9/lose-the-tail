# Production materials
- [x] G1: Every specified screen state and editor graphic exists as a readable PNG; manifest maps files to shots.
  CHECK: python3 verify.py
  EXPECT: KIT_VERIFIED
  EVIDENCE: automatic-evidence=v1; definition-sha256=61e324e96763141f9f1fd98a5e46cffea349957182488c38b6f6124a83c40453; exit=0; EXPECT=matched; output-sha256=1d17abf562b2ab2b34d44f9ac38cbc6a1688614d9c00d118abf9426d131f51bf; output-bytes=108; shell=/bin/sh; cwd=/Users/gadgetplug/Documents/vibecoding/lose-the-tail/trailer-workshop/production-kit; path=a42dff3919ac/31 entries
- [x] G2: Upload guide covers all 26 shots, supplied character references, finished screen option, compositing option, audio and known generation limits.
  EVIDENCE: Reviewed contact sheet and full-resolution unshield screen. START-HERE includes all 26 shot upload lists, screen sequence directions, no-blank-screen prompt, compositing fallback, official logo provenance, corrected audio, and explicit environment-reference and sound limitations.
