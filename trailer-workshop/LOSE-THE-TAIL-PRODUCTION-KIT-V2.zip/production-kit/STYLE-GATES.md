# Voxel noir redesign
- [x] G1: All 35 generated graphics rebuilt with pixel typography, dimensional icons and purpose-specific layouts; existing file mappings preserved.
  EVIDENCE: Rebuilt all 35 generated graphics using source/redesign.py. Inspected full-resolution wallet, end card and surveillance monitor. Regenerated gallery and overview. Corrected speaker masthead overprinting. Preserved official logos and file dimensions.
- [ ] G2: Pack passes asset checks and updated gallery and ZIP contain redesigned files.
  CHECK: python3 verify_style.py
  EXPECT: STYLE_VERIFIED
